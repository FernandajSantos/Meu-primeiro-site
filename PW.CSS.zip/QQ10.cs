﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            string Nome3 = "Fernanda de jesus santos";
            string Nome4 = "João Henrique da silva Costa";

            Nome3 = Nome3.ToUpper();

            Console.WriteLine("Primeiro nome: " + Nome3);
            Console.WriteLine("Segundo nome: " + Nome4.ToUpper());



            string Nome = "Fernanda de jesus santos";
            int tamanho = Nome.Length;
            string Nome2 = "João Henrique da silva costa";
            int tamanho2 = Nome2.Length;

            Console.WriteLine("Esse nome possui : " + tamanho + " caracteres");
            Console.WriteLine("O segundo nome possui : " + tamanho2 + " caracteres");

            string Nome5 = "Fernanda";
            Nome5 = Nome5.Substring(0, 3);
            string Nome6 = "joão";
            Nome6 = Nome6.Substring(0, 3);

            Console.WriteLine("Os três primeiros caracteres desse nome são : " + Nome5);
            Console.WriteLine("Os três primeiros caracteres desse nome são : " + Nome6);



            Console.ReadKey();
        }
    }
}
